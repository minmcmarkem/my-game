import pygame
import globalss
import the_game
global cursor_slot
import player_
import weapons
cursor_slot=pygame.sprite.Group()
global player_slot_list
player_slot_list=pygame.sprite.Group()

global kgbx
global kgby
import time
kgbx=0
kgby=100
global slotimg
global item
slot_image=pygame.image.load("images/slot.png")

class Cursor_slot (pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image=None

    def update (self):
        for item in cursor_slot:
            pos = pygame.mouse.get_pos()
            cursor_x = pos[0]
            cursor_y = pos[1]
            globalss.win.blit(pygame.image.load(item.image),( cursor_x,cursor_y))
            #print ('111')
    def kills (self):
        for item in cursor_slot:
            item.rect.x=player_.player_x+100
            item.rect.y=player_.player_y+100
            cursor_slot.remove(item)
            globalss.all_items_list.add(item)
            

def make_inventory ():
    global ddd
    ddd=0
    global kgbx
    global kgby
    bee=-1
    global equip_slot_1
    equip_slot_1=Equip_slot_1()
    while ddd<192:
        bee=bee+1
        kgbx=kgbx+50
        if bee>15:
            kgby=kgby+50
            kgbx=50
            bee=0
        
        slot=Slot (ddd,kgbx,kgby)   
        ddd=ddd+1


class Equip_slot_1 (pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        global item


        self.image=("images/slot.png")
        self.rect=slot_image.get_rect()
        self.rect.x=890
        self.rect.y=300
        self.starting_x=890
        self.starting_y = 300
        self.list=pygame.sprite.Group()
        globalss.player_equip_slot_list_1.add(self)

    def update(self):
        global item
        pos = pygame.mouse.get_pos()
        cursor_x = pos[0]
        cursor_y = pos[1]
        pygame.event.get()

        globalss.win.blit(pygame.image.load(self.image).convert_alpha(), (self.rect.x, self.rect.y))

        if cursor_x > self.rect.x:

            if cursor_x < self.rect.x + 40:

                if cursor_y > self.rect.y:

                    if cursor_y < self.rect.y + 40:

                        ggg = pygame.mouse.get_pressed()
                        if ggg == (1, 0, 0):

                            time.sleep(.1)
                            bing = 0
                            print(self.list)
                            print(cursor_slot)
                            for item in cursor_slot:
                                if cursor_slot in cursor_slot:
                                    ansc = cursor_slot
                                    anss = self.list

                                    if str(anss) == str("<Group(0 sprites)>"):
                                        self.list.add(item)
                                        cursor_slot.remove(item)
                                        self.image = item.image
                                        bing = 1

                            if bing == 0:

                                for item in self.list:
                                    if item in self.list:
                                        ansc = cursor_slot
                                        anss = self.list

                                        if str(ansc) == ("<Group(0 sprites)>"):
                                            print("aaa")
                                            cursor_slot.add(item)
                                            self.list.remove(item)
                                            self.image = ("images/slot.png")
                        # print (cursor_slot)
                        if ggg == (0, 0, 1):
                            for item in self.list:
                                if item in self.list:
                                    item.rect.x = player_.player_x + 100
                                    item.rect.y = player_.player_y + 100
                                    self.list.remove(item)
                                    globalss.all_items_list.add(item)
                                    # globalss.all_sprites_list.add(item)
                                    self.image = ("images/slot.png")
                                    player_.player_inventory_space_taken = player_.player_inventory_space_taken - 1



class Slot (pygame.sprite.Sprite):
    def __init__(self,ddd,kgbx,kgby):
        super().__init__()


        self.rect=slot_image.get_rect()
        self.rect.x=kgbx
        self.rect.y=kgby
        self.starting_x=kgbx
        self.starting_y = kgby
        self.list=pygame.sprite.Group()
        player_slot_list.add(self)
        self.image=pygame.image.load("images/slot.png").convert_alpha()
        self.d=ddd
        
    def update (self):

        pos = pygame.mouse.get_pos()
        cursor_x = pos[0]
        cursor_y = pos[1]
        pygame.event.get()
        for item in self.list:
            if self.image != pygame.image.load(item.image).convert_alpha():
                self.image=pygame.image.load(item.image).convert_alpha()
        globalss.win.blit(self.image,(self.rect.x, self.rect.y))
        
        if cursor_x>self.rect.x:
            
            if cursor_x<self.rect.x+40:
                
                if cursor_y>self.rect.y:
                    
                    if cursor_y<self.rect.y+40:
                        
                        ggg=pygame.mouse.get_pressed()
                        if ggg== (1,0,0):
                           
                            time.sleep(.1)
                            bing=0
                            print (self.list)
                            print (cursor_slot)
                            for item in cursor_slot:
                                if cursor_slot in cursor_slot:
                                    ansc=cursor_slot
                                    anss=self.list
                                    
                                    if str(anss)==str("<Group(0 sprites)>"):
                                        
                                        self.list.add(item)
                                        cursor_slot.remove(item)
                                        self.image=self.image=pygame.image.load(item.image).convert_alpha()
                                        bing=1

                            if bing==0:
                                
                                for item in self.list:
                                    if item in self.list:                            
                                        ansc=cursor_slot
                                        anss=self.list
                                        
                                        if str(ansc) ==("<Group(0 sprites)>"):
                                            
                                            print ("aaa")
                                            cursor_slot.add(item)
                                            self.list.remove(item)
                                            self.image=pygame.image.load("images/slot.png").convert_alpha()
                        #print (cursor_slot)
                        if ggg== (0,0,1):
                            for item in self.list:
                                item.rect.x=player_.player_x+100
                                item.rect.y=player_.player_y+100
                                self.list.remove(item)
                                globalss.all_items_list.add(item)
                                #globalss.all_sprites_list.add(item)
                                self.image=pygame.image.load("images/slot.png").convert_alpha()



class Buy_slot(pygame.sprite.Sprite):
    def __init__(self, list, item, x, y):

        super().__init__()


        self.image =pygame.image.load("images/buy_slot.png").convert_alpha()
        self.rect = slot_image.get_rect()
        self.rect.x = x
        self.rect.y =y

        self.item=item
        self.item_image=pygame.image.load(item.image).convert_alpha()

        self.d = ddd
        list.slots.add(self)

    def update(self):
        globalss.win.blit(self.image, (self.rect.x, self.rect.y))
        globalss.win.blit(self.item_image, (self.rect.x, self.rect.y))

        pos = pygame.mouse.get_pos()
        cursor_x = pos[0]
        cursor_y = pos[1]
        pygame.event.get()
        print (111)


        if cursor_x > self.rect.x:

            if cursor_x < self.rect.x + 200:

                if cursor_y > self.rect.y:

                    if cursor_y < self.rect.y + 50:

                        ggg = pygame.mouse.get_pressed()
                        if ggg == (1, 0, 0):
                            print ("111111")
                            time.sleep(.5)
                            player_.inventory(self.item)

        
            
def inventory_on ():
    cursor=Cursor_slot()
    inventory_true=1
    inventory_image=pygame.image.load("images/inventory.png").convert_alpha()
    for slot in player_slot_list:
        slot.rect.x=slot.starting_x
        slot.rect.y = slot.starting_y
    equip_slot_1.rect.x=equip_slot_1.starting_x
    equip_slot_1.rect.y = equip_slot_1.starting_y
    while inventory_true==1:
        
        keys = pygame.key.get_pressed()
        globalss.win.blit(inventory_image,( 50,50))
        
       
        #player_slot_list.draw(globalss.win)
        globalss.player_equip_slot_list_1.update()
        #globalss.player_equip_slot_list_1.draw(globalss.win)
        player_slot_list.update ()
        cursor.update()
        pygame.display.flip()
        pygame.event.get ()


        pos = pygame.mouse.get_pos()
        cursor_x = pos[0]
        cursor_y = pos[1]
        
              
        if keys[pygame.K_h]:
            
            inventory_true=0
            cursor.kills()
            the_game.run()


class Trade_inventory (pygame.sprite.Sprite):
    def __init__(self, selling):
        super().__init__()
        self.selling=selling
        self.image=("images/shop.png")
        self.list=selling
        self.slots=pygame.sprite.Group()
        self.rect=pygame.image.load(self.image).get_rect()
        self.rect.x=500
        self.rect.y=500

        globalss.static_mesh.add(self)



    def update (self):

        global shop_image
        try:
            """                 \/"""
            globalss.win.blit(shop_image, (self.rect.x, self.rect.y))



        except NameError:
            """     \/"""
            shop_image = pygame.image.load(self.image).convert_alpha()
            """                    \/"""
            globalss.win.blit(shop_image, (self.rect.x, self.rect.y))

        a = pygame.sprite.spritecollide(self, globalss.playerss, False)
        for player in a:
            keys = pygame.key.get_pressed()

            if keys[pygame.K_e]:
                x = 1000
                y = -40
                for item in self.list:
                    bx = 0
                    by = 0
                    y = y + 55
                    buy_slot = Buy_slot(self, item, x, y)
                    print ('BBB')
                self.trading_on()



    def trading_on(self):
        print (222)
        trading_true = 1
        cursor = Cursor_slot()
        inventory_image = pygame.image.load("images/inventory.png")
        trading_background_image = pygame.image.load("images/trading_background.png")
        for slot in player_slot_list:
            slot.rect.x = slot.starting_x - 50
            slot.rect.y = slot.starting_y + 100
        equip_slot_1.rect.x = 2000
        equip_slot_1.rect.y = 2000
        while trading_true == 1:

            keys = pygame.key.get_pressed()
            globalss.win.blit(inventory_image, (0, 150))

            player_slot_list.update()

            # globalss.player_equip_slot_list_1.draw(globalss.win)
            player_slot_list.update()
            cursor.update()


            globalss.win.blit(trading_background_image, (800, 0))
            player_slot_list.update()
            self.slots.update()

            self.list.update()
            pygame.display.flip()

            pygame.event.get()


            pos = pygame.mouse.get_pos()
            cursor_x = pos[0]
            cursor_y = pos[1]

            if keys[pygame.K_h]:
                trading_true = 0
                cursor.kills()
                for buy_slot in self.slots:
                    buy_slot.kill()
                the_game.run()


'''
def trading_on():

    trading_true = 1
    cursor = Cursor_slot()
    inventory_image = pygame.image.load("images/inventory.png")
    trading_background_image = pygame.image.load("images/trading_background.png")
    for slot in player_slot_list:
        slot.rect.x = slot.starting_x - 50
        slot.rect.y = slot.starting_y + 100
    equip_slot_1.rect.x = 2000
    equip_slot_1.rect.y = 2000
    while trading_true == 1:

        keys = pygame.key.get_pressed()
        globalss.win.blit(inventory_image, (0, 150))

        # player_slot_list.draw(globalss.win)
        globalss.player_equip_slot_list_1.update()
        # globalss.player_equip_slot_list_1.draw(globalss.win)
        player_slot_list.update()
        cursor.update()
        
        globalss.win.blit(trading_background_image, (800, 0))

        pygame.display.flip()
        pygame.event.get()

        pos = pygame.mouse.get_pos()
        cursor_x = pos[0]
        cursor_y = pos[1]

        if keys[pygame.K_h]:
            trading_true = 0
            cursor.kills()
            the_game.run()
'''


