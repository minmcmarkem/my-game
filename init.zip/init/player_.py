import pygame
import globalss
import player_inventory
import globalss
import weapons
import time
import non_entitys
import math
import player_things
global b
global rot
rot=0
b=1
speed=8
###################################################
global player_x
global player_y
global player_inventory_space_taken
global item
player_inventory_space_taken=0
player_x=1
player_y=1
class Player (pygame.sprite.Sprite):
    global g
    global speed
    global player_x
    global player_y
    global playerimg
    def __init__(self,x,y):
        global playerimg
        super().__init__()
        self.health=100
        self.collision=0
        playerimg=player_img=pygame.image.load("images/person.jpg").convert()
        self.image = playerimg
        self.rect = self.image.get_rect()
        self.rect.x=x
        self.rect.y=y
        self.r=0
        self.inventory_space=10
        self.inventory_taken=0
        self.slots_taken=0
        player_inventory.make_inventory ()
        globalss.playerss.add(self)
        self.r=0            
    def update (self):
        global playerimg
        global player_x
        global player_y
        player_x=self.rect.x
        player_y=self.rect.y
        


        
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_a]:
            globalss.rot=180
            self.rect.x=self.rect.x-speed
            self.image=pygame.transform.rotate(playerimg, 180)
            
        if keys[pygame.K_d]:
            globalss.rot=0
            self.image=pygame.transform.rotate(playerimg, 0)
            self.rect.x=self.rect.x+speed
        if keys[pygame.K_w]:
            globalss.rot=90
            self.image=pygame.transform.rotate(playerimg, 90)
            self.rect.y=self.rect.y-speed
        if keys[pygame.K_s]:
            globalss.rot=270
            self.image=pygame.transform.rotate(playerimg, 270)
            self.rect.y=self.rect.y+speed
        
        if self.health<1:
            self.kill()
            globalss.all_sprites_list.remove(self)
            globalss.entitys.remove(self)
        if keys[pygame.K_r]:
            self.rect.y=self.rect.y+speed
            
        if keys[pygame.K_y]:
            player_inventory.inventory_on()
        if keys[pygame.K_e]:
            pass

        if keys[pygame.K_n]:

            player_things.create()
        if keys[pygame.K_b]:
            pos = pygame.mouse.get_pos()
            cursor_x = pos[0]
            cursor_y = pos[1]
            item=weapons.Shotgun(cursor_x,cursor_y)
        if keys[pygame.K_l]:
            pos = pygame.mouse.get_pos()
            cursor_x = pos[0]
            cursor_y = pos[1]
            item=weapons.Ak(cursor_x,cursor_y)
        if keys[pygame.K_p]:
            pos = pygame.mouse.get_pos()
            cursor_x = pos[0]
            cursor_y = pos[1]
            non_entity=non_entitys.Tree(cursor_x,cursor_y)
        if keys[pygame.K_m]:
            pos = pygame.mouse.get_pos()
            cursor_x = pos[0]
            cursor_y = pos[1]
            non_entity=non_entitys.Small_red_block(cursor_x,cursor_y)
            
        if keys[pygame.K_y]:
            player_inventory.inventory_on()
        ggg=pygame.mouse.get_pressed()
        if ggg== (1,0,0):
            for item in globalss.player_equip_slot_list_1:
            
                for item in item.list:
                    item.use(player_x,player_y)
                    

    
    
            
                   
        a = pygame.sprite.spritecollide(self, globalss.non_entitys_list, False)
        for non_entity in a:
            
            self.rect.x=player_x
            self.rect.y=player_y
        b=pygame.sprite.spritecollide(self, globalss.all_items_list, False)
        for item in b:
            inventory(item)


def inventory (item):
    global b
    global player_inventory_space_taken
    b=1
    for slot in player_inventory.player_slot_list:
        if b==1:

            gdp=slot.list

            if str(gdp) == ("<Group(0 sprites)>"):

                b=0
                slot.list.add(item)
                #globalss.player_inventory.add(item)
                globalss.all_items_list.remove(item)

                slot.image=item.image
                
            
                        
    

def make_inventory ():
    pass
