import player_
import pickle
import globalss

class Chunk ():
    def __init__(self,x,y,background_color):
        super().__init__()
        self.background_color=background_color
        self.x=x
        self.y=y
        self.entity_list=open("map/chunks/"+(str(self.x))+"_"+(str(self.y))+"non-entitys.txt","x")
        globalss.chunks.append(self)

def map_update ():
    
    for player in globalss.playerss:
        if player.rect.x>1200:
            player.rect.x=0
            globalss.current_chunk_x=globalss.current_chunk_x+1
            load()
        if player.rect.x<0:
            player.rect.x=1200
            globalss.current_chunk_x=globalss.current_chunk_x-1
            load()
        if player.rect.y>800:
            player.rect.y=0
            globalss.current_chunk_y=globalss.current_chunk_y-1
            load()
        if player.rect.y<0:
            globalss.current_chunk_y=globalss.current_chunk_y+1
            player.rect.y=800
            load()
    



def load ():

    ##################none-entitys
   
    try:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "non_entitys.txt", "wb")
        pickle.dump(globalss.non_entitys_list,ggg)
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "non_entitys.txt", "wb")
        pickle.dump(globalss.non_entitys_list, ggg)
    


        
    try:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "non_entitys.txt", "rb")
        
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "non_entitys.txt", "xb")
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "non_entitys.txt", "rb")
    
    

    try:
        for non_entity in globalss.non_entitys_list:
            non_entity.kill()
        globalss.non_entitys_list=pickle.load(ggg)
    except EOFError:
        pass


############################items
    try:
        ggg = open(
            "map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "items.txt",
            "wb")
        pickle.dump(globalss.all_items_list, ggg)
    except IOError:
        ggg = open(
            "map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "items.txt",
            "wb")
        pickle.dump(globalss.all_items_list, ggg)

    try:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (
            str(globalss.current_chunk_y)) + "items.txt", "rb")

    except IOError:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (
            str(globalss.current_chunk_y)) + "items.txt", "xb")
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (
            str(globalss.current_chunk_y)) + "items.txt", "rb")

    try:
        print ("bbb")
        for item in globalss.all_items_list:
            globalss.all_items_list.remove((item))
            item.kill()
        globalss.all_items_list = pickle.load(ggg)
    except EOFError:
        print ("aaa")

    ############################static_mesh


    try:
        ggg = open(
            "map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "static_mesh.txt", "wb")
        pickle.dump(globalss.static_mesh, ggg)
    except IOError:
        ggg = open(
            "map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "static_mesh.txt", "wb")
        pickle.dump(globalss.static_mesh, ggg)

    try:
        ggg = open(
            "map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "static_mesh.txt",
            "rb")

    except IOError:
        ggg = open(
            "map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "static_mesh.txt",
            "xb")
        ggg = open(
            "map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "static_mesh.txt",
            "rb")

    try:
        for static_thing in globalss.static_mesh:
            static_thing.kill()
        globalss.static_mesh = pickle.load(ggg)
    except EOFError:
        pass



    #globalss.non_entitys = pickle.load(ggg)
    globalss.last_chunk_x=globalss.current_chunk_x
    globalss.last_chunk_y=globalss.current_chunk_y




    
    '''print (globalss.non_entitys_pygame)
    try:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "non_entitys.txt", "x")
        ggg.write(str(globalss.non_entitys_txt))
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "non_entitys.txt", "w")
        ggg.write(str(globalss.non_entitys_txt))
        if str(globalss.non_entitys_pygame) !=("<Group(0 sprites)>"):
            globalss.non_entitys_pygame.remove(pos(0)) 




            
    x=(len(globalss.non_entitys_txt))
    while x >0:
        x=(len(globalss.non_entitys_txt))
        globalss.non_entitys_pygame.remove(pos[1])
    
    x=(len(globalss.non_entitys_txt))
    while x >0:
        x=(len(globalss.non_entitys_txt))
        globalss.non_entitys_txt.remove(pos[1])

    try:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "non_entitys.txt", "x")
        bebe=ggg.read()
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "non_entitys.txt", "r")
        bebe=ggg.read()
    print (bebe)
    #x=(len(ggg))
    #print (x)
    

    globalss.last_chunk_x=globalss.current_chunk_x
    globalss.last_chunk_y=globalss.current_chunk_y'''




























    
    '''
    try:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "entitys.txt", "wb")
        pickle.dump(globalss.entitys,ggg)
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "entitys.txt", "wb")
        pickle.dump(globalss.entitys, ggg)
    try:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "non_entitys.txt", "wb")
        pickle.dump(globalss.non_entitys_list,ggg)
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "non_entitys.txt", "wb")
        pickle.dump(globalss.non_entitys_list, ggg)
    try:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "items.txt", "wb")
        pickle.dump(globalss.items, ggg)
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.last_chunk_x)) + "_" + (str(globalss.last_chunk_y)) + "items.txt", "wb")
        pickle.dump(globalss.items, ggg)


        
    try:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "entitys.txt", "xb")
        
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "entitys.txt", "wb")
        
    try:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "items.txt", "xb")
        
    except IOError:
        ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "items.txt", "wb")
        

    ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "entitys.txt", "rb")
    try:
        globalss.entitys=pickle.load(ggg)
    except EOFError:
        pass

        
    ggg = open("map/chunks/" + (str(globalss.current_chunk_x)) + "_" + (str(globalss.current_chunk_y)) + "items.txt", "rb")
    try:
        globalss.items = pickle.load(ggg)
    except EOFError:
        pass

    #globalss.non_entitys = pickle.load(ggg)
    globalss.last_chunk_x=globalss.current_chunk_x
    globalss.last_chunk_y=globalss.current_chunk_y

    '''
        
    
        



'''
    f=open()
    with open("gut.txt", "wb") as f:
        pickle.dump(bebe, f, 0)'''


    
