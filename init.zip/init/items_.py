import projectiles
import pygame
import globalss


class Wood(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        """                  \/     """
        self.image = ("images/wood.png")

        self.rect = (pygame.image.load(self.image)).get_rect()
        self.rect.x = x
        self.rect.y = y
        globalss.all_items_list.add(self)

    def update(self):
        """         \/"""
        global wood_image

        try:
            """                          \/"""
            globalss.win.blit(wood_image, (self.rect.x, self.rect.y))


        except NameError:
            """     \/"""
            wood_image = pygame.image.load(self.image).convert_alpha()
            """                    \/"""
            globalss.win.blit(wood_image, (self.rect.x, self.rect.y))

    def remove(self):
        globalss.all_items_list.remove(self)
        self.kill()

    def use(self, x, y):
        #       use time
        if globalss.t > 50:
            globalss.t = 0
            # starting pos x, starting pos y,randomness ,speed, damage.
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)
            bullet = projectiles.Bullet(x, y, 30, .2, 8)


