import projectiles
import pygame
import globalss


class Shotgun (pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()

        """                  \/     """
        self.image=("images/shotgun.png")
        self.value=130
        self.rect =(pygame.image.load(self.image)).get_rect()
        self.rect.x=x
        self.rect.y=y
        globalss.all_items_list.add(self)


    def update (self):
        """         \/"""
        global shotgun_image

        try:
            """                          \/"""
            globalss.win.blit(shotgun_image, (self.rect.x, self.rect.y))


        except NameError:
            """     \/"""
            shotgun_image = pygame.image.load(self.image).convert_alpha()
            """                    \/"""
            globalss.win.blit(shotgun_image, (self.rect.x, self.rect.y))



    def remove (self):
        globalss.all_items_list.remove(self)
        self.kill()
    
    def use (self,x,y):
        #       use time
        if globalss.t>50:
            globalss.t=0
            #starting pos x, starting pos y,randomness ,speed, damage.
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
            bullet=projectiles.Bullet(x,y,30,.2,8)
    def info (self):
        image = ("images/shotgun.png")
        value = 130




class Minigun(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        """         \/     """
        global minigun_image
        """                  \/     """
        self.image = ("images/minigun.png")
        """      \/          """
        minigun_image = pygame.image.load(self.image).convert_alpha()
        self.image = (self.image)

        """              \/     """
        self.rect=(pygame.image.load(self.image)).get_rect()
        self.rect.x = x
        self.rect.y = y
        globalss.all_items_list.add(self)
        """                      \/          """
        globalss.win.blit(minigun_image, (self.rect.x, self.rect.y))

    def update(self):
        """           \/     """
        global minigun_image
        """                     \/     """
        globalss.win.blit(minigun_image, (self.rect.x, self.rect.y))
        '''a = pygame.sprite.spritecollide(self, globalss.playerss, False)
        for player in a:
            player.inventory(self)'''

    def remove(self):
        globalss.all_items_list.remove(self)

    def use(self, x, y):

        if globalss.t > 1:
            globalss.t = 0
            #                          starting pos x, starting pos y,randomness ,speed, damage.
            bullet = projectiles.Bullet(x, y, 8, .2, 13)


class Ak (pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()

        """                  \/     """
        self.image=("images/ak.png")
        self.value = 250
        self.rect =(pygame.image.load(self.image)).get_rect()
        self.rect.x=x
        self.rect.y=y
        globalss.all_items_list.add(self)


    def update (self):
        """         \/"""
        global ak_image

        try:
            """                 \/"""
            globalss.win.blit(ak_image, (self.rect.x, self.rect.y))


        except NameError:
            """     \/"""
            ak_image = pygame.image.load(self.image).convert_alpha()
            """                    \/"""
            globalss.win.blit(ak_image, (self.rect.x, self.rect.y))



    def remove (self):
        globalss.all_items_list.remove(self)
        self.kill()
    
    def use (self,x,y):
        #       use time
        if globalss.t>9:
            globalss.t=0
            #starting pos x, starting pos y,randomness ,speed, damage.
            bullet=projectiles.Bullet(x,y,8,.3,12)

    def info (self):
        self.image = ("images/shotgun.png")
        self.value = 130
            









