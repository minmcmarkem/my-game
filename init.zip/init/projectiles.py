import pygame
import globalss
import time
import math
import random
global g
bullet_image=("images/bullet.png")

class Bullet(pygame.sprite.Sprite):
    global cursor_x
    global cursor_y
    def __init__(self, selfx, selfy, rando, vel, damage):
        super().__init__()
        self.image = bullet_image
        
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x, rel_y = mouse_x - (selfx+20), mouse_y - (selfy+20)
        angle = (180 / math.pi) * -math.atan2(rel_y, rel_x)
        self.imager=pygame.transform.rotate(pygame.image.load(self.image), int(angle))
        
        self.rect = self.imager.get_rect()

        self.rect.x = selfx
        self.rect.y = selfy
        pos = pygame.mouse.get_pos()
        cursor_x = pos[0]
        cursor_y = pos[1]
        velocity = 100
        self.x_diff=(cursor_x- self.rect.x)
        self.y_diff=(cursor_y- self.rect.y)
        angle = math.atan2(self.y_diff, self.x_diff)
        self.vec_x = math.cos(angle) * velocity
        self.vec_y = math.sin(angle) * velocity
        self.rando_x=((self.vec_x+random.randrange(0,rando))*vel)
        self.rando_y=((self.vec_y+random.randrange(0,rando))*vel)
        self.rect.x = self.rect.x+(self.rando_x*3)
        self.rect.y = self.rect.y+(self.rando_y*3)
        

        globalss.bullet_list.add(self)
        
        self.b=0
        
        self.damage=damage

        
    def update(self):
        globalss.win.blit(self.imager, (self.rect.x, self.rect.y))
        #self.b=self.b+1
        self.rect.x=(self.rect.x+self.rando_x)
        self.rect.y=(self.rect.y+self.rando_y)
        '''if self.b>1:
            self.rect.x += self.vec_x
            self.rect.y += self.vec_y
            self.b=0'''
        if self.rect.x>2000:
            #globalss.all_sprites_list.remove(self)
            globalss.bullet_list.remove(self)
            self.kill()
        if self.rect.x<-100:
            #globalss.all_sprites_list.remove(self)
            globalss.bullet_list.remove(self)
            self.kill()
        if self.rect.y<-100:
            #globalss.all_sprites_list.remove(self)
            globalss.bullet_list.remove(self)
            self.kill()
        if self.rect.y>1000:
            #globalss.all_sprites_list.remove(self)
            globalss.bullet_list.remove(self)
            self.kill()
        
            
   
        b=pygame.sprite.spritecollide(self, globalss.playerss, False)
        for entity in b:
            entity.health=entity.health-self.damage
            globalss.bullet_list.remove(self)
            #globalss.all_sprites_list.remove(self)
            self.kill()
        a=pygame.sprite.spritecollide(self, globalss.non_entitys_list, False)
        for non_entity in a:
            non_entity.health=non_entity.health-self.damage
            globalss.bullet_list.remove(self)
            #globalss.all_sprites_list.remove(self)
            self.kill()

        
        
            
