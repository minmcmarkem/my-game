import globalss
import player_
import math
import pygame
import player_inventory
import weapons
import time
def A ():
    
    global rot
    global bob
    rot=0
    for item in globalss.player_equip_slot_list_1:
        for item in item.list:
            ge=item.image
            mouse_x, mouse_y = pygame.mouse.get_pos()
            rel_x, rel_y = mouse_x - (player_.player_x+20), mouse_y - (player_.player_y+20)
            angle = (180 / math.pi) * -math.atan2(rel_y, rel_x)

            BEN = pygame.image.load(ge)
            
            if rot!=angle:
                if angle >90 or angle <-90:
                    
                    rot=-1*angle

                    shown_item_image=pygame.transform.rotate((BEN),(int(1*(int(rot)))))
                    shown_item_image=pygame.transform.flip((shown_item_image),0,1)
                    globalss.win.blit(shown_item_image, (player_.player_x - 10, player_.player_y - 10))

                    
                else:
                    rot=angle
                    shown_item_image=pygame.transform.rotate(pygame.image.load(ge), int(rot))
                    globalss.win.blit(shown_item_image, (player_.player_x - 10, player_.player_y - 10))
            if angle == -0.0:
                globalss.win.blit(BEN, (player_.player_x - 10, player_.player_y - 10))

    B ()

def B ():
    pass

def create ():
    selling = pygame.sprite.Group()
    item=weapons.Shotgun(2000,2000)
    selling.add(item)
    item = weapons.Ak(2000,2000)
    selling.add(item)


    static_thing=player_inventory.Trade_inventory(selling)
    time.sleep(.5)
