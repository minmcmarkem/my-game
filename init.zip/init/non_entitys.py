import pygame
import globalss
import items_
#tree_image=pygame.image.load("images/tree.png").convert_alpha()

class Tree(pygame.sprite.Sprite):
    def __init__(self,x,y):
        
        super().__init__()
        """           \/"""
        global tree_image
        """           \/"""
        self.image = ("images/tree.png")
        """                                  \/"""
        tree_image=pygame.image.load(self.image).convert_alpha()
        """           \/"""

        """           \/"""
        self.rect=tree_image.get_rect()
        self.rect.x=x
        self.rect.y=y
        self.health=500
        globalss.non_entitys_list.add(self)
        
        
        
    def update (self):
        """           \/"""
        global tree_image
        try:
            """                 \/"""
            globalss.win.blit(tree_image, (self.rect.x, self.rect.y))


        except NameError:
            """     \/"""
            ak_image = pygame.image.load(self.image).convert_alpha()
            """                    \/"""
            globalss.win.blit(ak_image, (self.rect.x, self.rect.y))

        if self.health<0:
            globalss.non_entitys_list.remove(self)
            item=items_.Wood(self.rect.x,self.rect.y)
            item=items_.Wood(self.rect.x,self.rect.y)
            item=items_.Wood(self.rect.x,self.rect.y)
            self.kill()
        

    def destroy (self):
        self.kill()



class Trade_inventory (pygame.sprite.Sprite):
    def __init__(self, selling):
        super().__init__()
        globalss.non_entitys_list.add(self)
        self.selling=selling
        self.list=pygame.sprite.Group()
        self.rect=self.image.get_rect()
        self.rect.x=500
        self.rect.y=500
        for item in selling:
            buy_slot=Buy_slot(self,item,800,100)
            self.image=pygame.image.load("images/shop.png")
    def update (self):
        self.list.update()


        

