import pygame
import globalss
import time
import math
import player_
import player_things
import the_map
import player_inventory
import weapons
global g


def s ():

    global player
    player=player_.Player(500,500)
    globalss.running=1
    globalss.win.fill((30,150,50))
    #print (weapons.Shotgun.image)

    run ()

def run ():

    global player
    
    while globalss.running==1:
        pygame.event.get ()
        
        
        globalss.all_sprites_list.update()
               
        globalss.win.fill((30,150,50))
        ###################     drawing
        #print (len(globalss.items))
        
        #globalss.all_sprites_list.draw(globalss.win)
        #globalss.entitys_pygame.draw(globalss.win)
        globalss.entitys_pygame.update()
        
        globalss.all_items_list.update()
        globalss.static_mesh.update()
        globalss.playerss.update()
        globalss.playerss.draw(globalss.win)
        player_things.A()
        globalss.non_entitys_list.update()
        globalss.bullet_list.update()
        #globalss.non_entitys_list.draw(globalss.win)
        #print (globalss.non_entitys_txt)
        the_map.map_update()
        pygame.display.update()
        #pygame.display.flip()
        globalss.t=globalss.t+1
        clock = pygame.time.Clock()
        clock.tick(90)
        

        

    
