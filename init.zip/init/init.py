

import sys
# insert at 1, 0 is the script path (or '' in REPL)
sys.path.insert(1, 'C:/Users/mintr/Desktop/ger')

import the_game
the_game.s ()
