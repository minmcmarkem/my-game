import pygame
import player_
#########################################     other things
global win
win=pygame.display.set_mode((1200, 800))
#########################################     lists     
global all_sprites_list
all_sprites_list = pygame.sprite.Group()

global static_mesh
static_mesh=pygame.sprite.Group()


global player_inventory
player_inventory=pygame.sprite.Group()
global player_inventory_list
global playerss
playerss=pygame.sprite.Group()


global all_items_list
all_items_list=pygame.sprite.Group()

global entitys_pygame
entitys_pygame=pygame.sprite.Group()
global non_entitys_list
non_entitys_list=pygame.sprite.Group()

global items_txt
items_txt=[]
global entitys_txt
entitys_txt=[]
global non_entitys_txt
non_entitys_txt=[]



global bullet
bullet_list=pygame.sprite.Group()
global current_chunk_x
current_chunk_x=0
global current_chunk_y
current_chunk_y=0
global last_chunk_x
last_chunk_x=0
global last_chunk_y
last_chunk_y=0
global f
f=0

global running
running=0
global chunks
chunks=[]
##########################################     game clock
global t
t=0
###########################################     player
global player_equip_slot_list_1
player_equip_slot_list_1=pygame.sprite.Group()










global rot
global bob
bob=0
rot=0
'''def equiped ():
    global rot
    global bob
    for item in player_equip_slot_list_1:
        for item in item.list:
            if bob!=rot:
                bob=rot
                item.image=pygame.transform.rotate(item.image, bob)
            win.blit(item.image,(player.player_x,player.player_y))'''
